﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    abstract class Armor : IEquippable
    {
        protected int defense = 0;

        public int Defense
        {
            get
            {
                return defense;
            }

            set
            {
                defense = value;
            }
        }

        virtual public void Equip(Character C) { }
    }
}

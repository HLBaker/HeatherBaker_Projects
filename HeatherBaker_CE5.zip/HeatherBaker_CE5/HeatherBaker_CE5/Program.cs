﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{

    class Program
    {
        static Character mainCharacter = new Character();


        static void Main(string[] args)
        {

            string userInput;
            Console.WriteLine("Welcome!\r\n\r\n");

            while (true)
            {
                DisplayCurrentCharacter();
                DisplayMenu();
                userInput = Console.ReadLine().ToLower();

                switch (userInput)
                {

                    case "1":
                    case "display status":
                        
                        DisplayCharacterInfo();

                        break;

                    case "2":
                    case "create weapon":
                        


                        break;

                    case "3":
                    case "create armor":
                        CreateArmorItem();


                        break;
                    case "4":
                    case "equip":


                        if (mainCharacter.equippableList.Count > 0)
                        {
                            EquipInventoryItem();
                        }
                        else {

                            Console.WriteLine("You do not have any items in your inventory. Please create one to equip.");


                        }


                            break;
                    case "5":
                    case "exit":
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Command not recognized.");
                        break;

                }

            }


        }

        public static void DisplayMenu() {

            Console.WriteLine("Please choose from the options below:\r\n\r\n1. Display Status\r\n2. Create Weapon\r\n3. Create Armor\r\n4. Equip\r\n5. Exit");
        }

        public static void DisplayCurrentCharacter()
        {
            Console.WriteLine("\r\nCurrent Character: " + mainCharacter.Name);
        }

        public static void DisplayCharacterInfo()
        {
            Console.WriteLine("\r\nCurrent character information:\r\nName: " + mainCharacter.Name + "\r\nGender: " + mainCharacter.Gender + "\r\nHealth: " + mainCharacter.Health + "\r\nBase Attack: " + mainCharacter.BaseAttack + "\r\nAccuracy: " + mainCharacter.Accuracy);

            Console.WriteLine("\r\n\r\nEquipped Armor:\r\n");
            if (mainCharacter.equippedDictionary.Count > 0)
            {
                foreach (string key in mainCharacter.equippedDictionary.Keys)
                {
                    Console.WriteLine("Type: " + mainCharacter.equippedDictionary);
                }

            }
            else { }

        }


        public static void CreateArmorItem()
        {
            string userInput;
            int armorInt;
            string armorType;

            Console.WriteLine("What is the defense value of your armor? Please enter a whole number.");


            while (true)
            {
                userInput = Console.ReadLine().ToLower();
                try
                {
                    armorInt = Convert.ToInt32(userInput);
                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Needs to be a whole number.");
                }
            }



            Console.WriteLine("Is this a helmet or a chestpiece?");

            while (userInput != "chestpiece" && userInput != "helmet") {
                userInput = Console.ReadLine().ToLower();

                if (userInput == "chestpiece") { 
                armorType = userInput;
                Chestpiece newChestpiece = new Chestpiece();
                newChestpiece.Defense = armorInt;

                mainCharacter.equippableList.Add(newChestpiece);
                Console.WriteLine("You have added a Chestpiece with a defense value of " + armorInt + " to your inventory.");
                 } else if (userInput == "helmet") {


                armorType = userInput;
                Helmet newHelmet = new Helmet();
                newHelmet.Defense = armorInt;
                mainCharacter.equippableList.Add(newHelmet);
                Console.WriteLine("You have added a Helmet with a defense value of " + armorInt + " to your inventory.");
                } else { 

                Console.WriteLine("This is not a valid input.\r\nIs your armor a helmet or a chestpiece.");
                
                    }
            

                }

            

        }

        //Create Weapon
        public static void CreateWeaponItem()
        {
            int weaponAttack = 0;
            string userInput = "";
            Weapon newWeapon = null;


            //get the attack value and validate that it is an int
            Console.WriteLine("Weapon's attack value? This needs to be a whole number.");
            while (true)
            {
                userInput = Console.ReadLine();
                try
                {
                    weaponAttack = Convert.ToInt32(userInput);
                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Needs to be a whole number.");
                }
            }


           
                    //set our local weapon variable
            newWeapon = new Weapon(weaponAttack);

            //Add new weapon to list of IEquippables
            mainCharacter.equippableList.Add(newWeapon);




                }

        //Equip inventory item
        public static void EquipInventoryItem()
        {
            string userInput;
            int i = 1;
            int equipIntInput;

            //Display items in equippableList
            foreach (Armor value in mainCharacter.equippableList)
            {
                Console.WriteLine("index [" + i + "] Value: " + value + "\r\n\r\n");
                i++;
            }

            

            while (true)
            {
                Console.WriteLine("Which item would you like to equip?\r\nPlease enter your answer in the form of an integer.");
                userInput = Console.ReadLine().ToLower();
                try
                {

                    equipIntInput = Convert.ToInt32(userInput);

                    if (equipIntInput <= mainCharacter.equippableList.Count && equipIntInput >= 0) {

                        mainCharacter.equippedDictionary.Values[equipIntInput] = 
                    }


                    
                }

                catch (FormatException)
                {

                    Console.WriteLine("This is not a valid entry. Please choose one of the equippable items by entering the integer index of the item");
                }

            }

            //Find item in list

            while()

            Console.WriteLine("You have chosen to equip " + mainCharacter.equippableDictionary + " with a defense value of " + mainCharacter.equippedDictionary[]);
        
        }
        
        
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Heather Baker
/// CE08
/// Travis Setz
/// ASD 1604
/// </summary>

namespace HeatherBaker_CE08
{
    class Program
    {
        private static String[] strArray = new String[5];

        public static string[] StrArray
        {
            get
            {
                return strArray;
            }

            set
            {
                strArray = value;
            }
        }

        static void Main(string[] args)
        {
            string userInput = "";
            Console.WriteLine("Welcome!");


            while (true)
            {
                Console.WriteLine("\r\nPlease select from the following options.\r\n1. Sort strings\r\n2. Exit");
                userInput = Console.ReadLine().ToLower();
                switch (userInput)
                {
                    case "1":
                    case "sort strings":
                        AssignArray();
                        AscOrDsc();

                        break;

                    case "2":
                    case "exit":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("You have not made a valid entry, please try again.");
                        break;
                }
            }

        }


        public static void AssignArray()
        {
            Console.WriteLine("\r\nPlease type 5 strings that you would like to sort, pressing enter after each one.");
            StrArray[0] = Console.ReadLine();
            StrArray[1] = Console.ReadLine();
            StrArray[2] = Console.ReadLine();
            StrArray[3] = Console.ReadLine();
            StrArray[4] = Console.ReadLine();
            Console.WriteLine("\r\n\r\nThe current order of strings:\r\n" + StrArray[0] + "," + StrArray[1] + "," + StrArray[2] + "," + StrArray[3] + "," + StrArray[4]);
        }

        //Ask user whether they would like to sort in ascending or decending order
        public static void AscOrDsc()
        {
            string userInput = "";
            Console.WriteLine("\r\n\r\nPlease select whether you would like to sort your information in ascending or descending order:\r\n\r\n1. Ascending\r\n2. Descending");



            while (userInput != "1" && userInput != "2" && userInput != "ascending" && userInput != "descending")
            {
                userInput = Console.ReadLine().ToLower();
                if (userInput == "1" || userInput == "ascending")
                {
                    Sort(StrArray, true);
                    Console.WriteLine("Here are your sorted strings:\r\n" + StrArray[0] + "," + StrArray[1] + "," + StrArray[2] + "," + StrArray[3] + "," + StrArray[4]);

                }
                else if (userInput == "2" || userInput == "descending")
                {
                    Sort(StrArray, false);
                    Console.WriteLine("Here are your sorted strings:\r\n" + StrArray[0] + "," + StrArray[1] + "," + StrArray[2] + "," + StrArray[3] + "," + StrArray[4]);

                }
                else
                {
                    Console.WriteLine("You have not made a valid entry, please try again.");
                }


            }

        }


        //Sort string array 
        public static void Sort(String[] unsorted, bool truAscFalseDesc)
        {

            //Sorts ascending
            if (truAscFalseDesc)
            {
                string arrayItem;


                //loops over items in arry starting at one and ending with the last entry
                for (int a = 0; a < unsorted.Count(); a++)
                {

                    //declares number variables
                    int b = a + 1;
                    int c = a;

                    //saves item being sorted into temporary variable
                    arrayItem = unsorted[a];

                    //loops over remaining tiems and assigns the lowest one to arrayItem and c
                    while (b <= unsorted.Count() - 1)
                    {
                        if (arrayItem.CompareTo(unsorted[b]) > 0)
                        {
                            arrayItem = unsorted[b];
                            c = b;
                        }
                        b++;
                    }

                    //Swaps lowest array item with next value in array
                    unsorted[c] = unsorted[a];
                    unsorted[a] = arrayItem;
                    Console.WriteLine("\r\n\r\nThe current order of strings:\r\n" + StrArray[0] + "," + StrArray[1] + "," + StrArray[2] + "," + StrArray[3] + "," + StrArray[4]);
                }
            }

            //Sorts descending
            else
            {
                //Sorts descending

                string arrayItem;

                //loops over items in arry starting at one and ending with the last entry
                for (int a = 0; a < unsorted.Count(); a++)
                {
                    int b = a + 1;
                    int c = a;
                    //saves item being sorted into temporary variable
                    arrayItem = unsorted[a];

                    //loops over remaining tiems and assigns the highest one to arrayItem and c
                    while (b <= unsorted.Count() - 1)
                    {
                        if (unsorted[b].CompareTo(arrayItem) > 0)
                        {
                            arrayItem = unsorted[b];
                            c = b;
                        }
                        b++;
                    }

                    //Swaps lowest array item with next value in array

                    unsorted[c] = unsorted[a];
                    unsorted[a] = arrayItem;
                    Console.WriteLine("\r\n\r\nThe current order of strings:\r\n" + StrArray[0] + "," + StrArray[1] + "," + StrArray[2] + "," + StrArray[3] + "," + StrArray[4]);
                }
            }


            //BUBBLE SORT
            // {
            //    string arrayItem;


            //    int b;

            //loops over items in arry starting at one and ending with the last entry
            //  for (int a = 0; a < unsorted.Count(); a++)
            //  {
            //      b = a + 1;
            //saves item being sorted into temporary variable
            //       arrayItem = unsorted[a];


            //       while (b < unsorted.Count())
            //      {
            //           if (arrayItem.CompareTo(unsorted[b]) < 0)
            //          {
            //               arrayItem = unsorted[b];
            //               unsorted[b] = unsorted[a];
            //                 unsorted[a] = arrayItem;

            //            }

            //             b++;
            //        }
            //      }
            //  }








        }

    }



}



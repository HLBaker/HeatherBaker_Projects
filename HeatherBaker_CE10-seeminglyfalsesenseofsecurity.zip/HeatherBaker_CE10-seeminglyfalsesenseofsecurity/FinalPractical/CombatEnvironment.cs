﻿using System;
using System.Collections.Generic;

namespace FinalPractical
{
    class CombatEnvironment
    {
        //probably need to store the combatants in this class
        List<Character> currentCharacters = new List<Character>();

        public CombatEnvironment(List<Character> combatantsParam)
        {
            //sorting combatants by speed would be a good idea

            
            Character tempCharacter;
            int b;

            for (int a = 0; a < combatantsParam.Count - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (combatantsParam[b - 1].Speed > combatantsParam[b].Speed)
                    {
                        tempCharacter = combatantsParam[b - 1];
                        combatantsParam[b - 1] = combatantsParam[b];
                        combatantsParam[b] = tempCharacter;
                    }
                    b--;
                }
            }
            //assign sorted list to combat environment character list
            currentCharacters = combatantsParam;
        }

        public void ResolveCombat()
        {
            //to start, display information about all combatants
            //when displaying information include the type of Character(Monster or Player), health, attack, defense, and speed
            Console.WriteLine("Your combatants:\r\n\r\n");
            foreach (Character c in currentCharacters)
            {
                Console.WriteLine("Type: " + c.TypeName);
                Console.WriteLine("Name: " + c.Name);
                Console.WriteLine("Health: " + c.Health);
                Console.WriteLine("Attack: " + c.Attack);
                Console.WriteLine("Defense: " + c.Defense);
                Console.WriteLine("Speed: " + c.Speed + "\r\n\r\n");
            }

            bool continueCombat = true;
            
            int i;

            while (continueCombat)
            {


                for (int n = 0; n <= (currentCharacters.Count - 1); n++)
                {
                    i = 0;

                    
                    if (currentCharacters[n].TypeName == "Player")
                    {
                        while (currentCharacters[i].TypeName != "Monster")
                        {
                            i++;
                        }
                        

                    }
                    else
                    {
                        while (currentCharacters[i].TypeName != "Player")
                        {
                            i++;
                        }
                    }

                    currentCharacters[n].AttackTarget(currentCharacters[i]);
                    if (currentCharacters[i].Health == 0)
                    {
                        currentCharacters.RemoveAt(i);
                    }

                    
                }
                Console.WriteLine("\r\n\r\nYou have reached the end of the round.\r\n\r\n");
                Console.WriteLine("Your combatants current status:\r\n\r\n");
                foreach (Character c in currentCharacters)
                {
                    Console.WriteLine("Type: " + c.TypeName);
                    Console.WriteLine("Name: " + c.Name);
                    Console.WriteLine("Health: " + c.Health);
                    Console.WriteLine("Attack: " + c.Attack);
                    Console.WriteLine("Defense: " + c.Defense);
                    Console.WriteLine("Speed: " + c.Speed + "\r\n\r\n");
                }
                
                continueCombat = CombatContinue(currentCharacters);
                //every round each Character should attack one other Character of the opposing type (Players attack Monsters, and Monsters attack Players)

                //The Characters should attack in the order of highest speed to lowest speed
                //If a Character's health falls to 0 or below 0 then it has died and should be removed from the CombatEnvironment
                //After each round of combat each Character's information should be displayed with updated health values
                //After each round of combat, check to see if all Players or all Monsters have died. If one side has no remaining objects, end the combat and display which side was victorious
            }
            Console.ReadLine();

        }
        //Check if there is a victor
        public bool CombatContinue(List<Character> ccList)
        {
            bool keepGoing = true;
            int playersLeft = 0;
            int monstersLeft = 0;

            foreach (Character c in ccList)
            {

                if (c.TypeName == "Player")
                {
                    playersLeft++;
                }
                else
                {
                    monstersLeft++;
                }

            }

            if(playersLeft == 0 || monstersLeft == 0)
            {
                keepGoing = false;
            }

            return keepGoing;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    interface IEquippable
    {
        void Equip(Character C);
    }
}

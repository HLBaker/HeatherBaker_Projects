﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    
    class Program
    {
        static Character mainCharacter = new Character();

        static void Main(string[] args)
        {

            string userInput;
            Console.WriteLine("Welcome!\r\n\r\n");

            while (true){
                DisplayCurrentCharacter();
                Console.WriteLine("Please choose from the options below:\r\n\r\n1. Display Status\r\n2. Create Weapon\r\n3. Create Armor\r\n4. Equip\r\n5. Exit");
                userInput = Console.ReadLine().ToLower();

                switch (userInput) {

                    case "1":
                    case "display status":
                        DisplayCurrentCharacter();
                        DisplayCharacterInfo();

                        break;

                    case "2":
                    case "create weapon":
                        DisplayCurrentCharacter();


                        break;

                    case "3":
                    case "create armor":
                        DisplayCurrentCharacter();

                        break;
                    case "4":
                    case "equip":
                        DisplayCurrentCharacter();


                        break;
                    case "5":
                    case "exit":
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Command not recognized.");
                        break;

                }

            }


        }

        public static void DisplayCurrentCharacter() {
            Console.WriteLine("\r\nCurrent Character: " + mainCharacter.Name);
        }

        public static void DisplayCharacterInfo()
        {
            Console.WriteLine("\r\nCurrent character information:\r\nName: " + mainCharacter.Name + "\r\nGender: " + mainCharacter.Gender + "\r\nHealth: " + mainCharacter.Health + "\r\nBase Attack: " + mainCharacter.BaseAttack + "\r\nAccuracy: " + mainCharacter.Accuracy);

            Console.WriteLine("\r\n\r\nEquipped Armor:\r\n");
            if (mainCharacter.equippedDictionary.Count > 0) {
                foreach (string key in mainCharacter.equippedDictionary) {
                    Console.WriteLine("Type: " + mainCharacter.equippedDictionary );
                }

            }

        }


        public static void CreateArmorItem(){

            Console.WriteLine("");
        
        
        }

        public static void CreateWeaponItem(){
        
        
        
        }

        public static void EquipInventoryItem(){
        
        
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    class Weapon : IEquippable
    {
        private int attack = 0;

        public int Attack
        {
            get
            {
                return attack;
            }

            set
            {
                attack = value;
            }

        }
        public void Equip(Character C)
        {
          

        }
    }
}


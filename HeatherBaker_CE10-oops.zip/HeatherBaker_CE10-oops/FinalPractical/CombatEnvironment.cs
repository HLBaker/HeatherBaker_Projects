﻿using System;
using System.Collections.Generic;

namespace FinalPractical
{
    class CombatEnvironment
    {
        //probably need to store the combatants in this class
        List<Character> currentCharacters = new List<Character>();

        public CombatEnvironment(List<Character> combatantsParam)
        {
            //sorting combatants by speed would be a good idea

            
            Character tempCharacter;
            int b;

            for (int a = 0; a < combatantsParam.Count - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (combatantsParam[b - 1].Speed > combatantsParam[b].Speed)
                    {
                        tempCharacter = combatantsParam[b - 1];
                        combatantsParam[b - 1] = combatantsParam[b];
                        combatantsParam[b] = tempCharacter;
                    }
                    b--;
                }
            }
            //assign sorted list to combat environment character list
            currentCharacters = combatantsParam;
        }

        public void ResolveCombat()
        {
            //to start, display information about all combatants
            //when displaying information include the type of Character(Monster or Player), health, attack, defense, and speed
            Console.WriteLine("Your combatants:\r\n\r\n");
            foreach (Character c in currentCharacters)
            {
                Console.WriteLine("Type: " + c.Type);
                Console.WriteLine("Name: " + c.Name);
                Console.WriteLine("Health: " + c.Health);
                Console.WriteLine("Attack: " + c.Attack);
                Console.WriteLine("Defense: " + c.Defense);
                Console.WriteLine("Speed: " + c.Speed + "\r\n\r\n");
            }

            int attackedIndex;
            bool continueCombat = true;
            while (continueCombat)
            {
                
                //every round each Character should attack one other Character of the opposing type (Players attack Monsters, and Monsters attack Players)
                foreach (Character c in currentCharacters)
                {
                    attackedIndex = 0;
                    if (c.Type == "Player")
                    {
                        while (currentCharacters[attackedIndex].Type == "Monster")
                        {
                            attackedIndex++;
                        }
                    }
                    else
                    {
                        while (currentCharacters[attackedIndex].Type == "Player")
                        {
                            attackedIndex++;
                        }
                    }

                    c.AttackTarget(currentCharacters[attackedIndex]);
                    if (currentCharacters[attackedIndex].Health == 0)
                    {
                        currentCharacters.RemoveAt(attackedIndex);
                    }

                }


            }
            //The Characters should attack in the order of highest speed to lowest speed
            //If a Character's health falls to 0 or below 0 then it has died and should be removed from the CombatEnvironment
            //After each round of combat each Character's information should be displayed with updated health values
            //After each round of combat, check to see if all Players or all Monsters have died. If one side has no remaining objects, end the combat and display which side was victorious
        }
    }
}

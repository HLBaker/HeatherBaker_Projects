﻿using System;
using System.Collections.Generic;

namespace FinalPractical
{
    class Player : Character
    {
        new private string type = "Player";

        public Player()
        {

        }
        public Player (string stringArrayItem)
        {
            Name = stringArrayItem;
            Health = Program.rand.Next(40, 60);
            Attack = Program.rand.Next(15, 20);
            Defense = Program.rand.Next(5, 10);
            Accuracy = (Program.rand.NextDouble() + Program.rand.Next(60, 79));
            Speed = Program.rand.Next(1, 10);

        }

        //type get
        new public string Type
        {
            get
            {
                return type;
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace FinalPractical
{
    class Program
    {
        //////DO NOT MODIFY!!!/////

        //Use this Random object for all randomly generated values throughout the application
        public static Random rand = new Random();

        static string[] characterNames = new string[] { "Garviel", "Potonoodle", "Tummyache", "Solex", "Livec", "Depress" };
        static string[] monsterNames = new string[] { "Ochu", "Giant", "Dragon", "Lizardman", "Golem", "Demon" };

        static void Main(string[] args)
        {
            Console.WriteLine("How many combatants will each team have?(1-6)");
            String userInput = Console.ReadLine();
            int characterCount = 0;
            Int32.TryParse(userInput, out characterCount);

            if(characterCount > 6)
            {
                characterCount = 6;
            }
            else if (characterCount <= 0)
            {
                characterCount = 3;
            }

            List<Character> characters = new List<Character>();
            for(int i = 0; i < characterCount; i++)
            {
                characters.Add(new Player(characterNames[i]));
            }
            for (int i = 0; i < characterCount; i++)
            {
                characters.Add(new Monster(monsterNames[i]));
            }

            CombatEnvironment env = new CombatEnvironment(characters);
            env.ResolveCombat();
        }
    }
}

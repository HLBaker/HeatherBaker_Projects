﻿using System;
using System.Collections.Generic;

namespace FinalPractical
{
    //this class must remain abstract
    abstract class Character
    {
        //these are the only required member variables of this class
        //other than name, these will need to be randomly generated when the class is instantiated
        protected string type;
        protected string name;
        protected int health;
        protected int attack;
        protected int defense;
        protected double accuracy;
        protected int speed;

        //Name get/set
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        //health get/set
        public int Health
        {
            get
            {
                return health;
            }

            set
            {
                health = value;
            }
        }

        //attack get/set
        public int Attack
        {
            get
            {
                return attack;
            }

            set
            {
                attack = value;
            }
        }

        //defense get/set
        public int Defense
        {
            get
            {
                return defense;
            }

            set
            {
                defense = value;
            }
        }

        //accuracy get/set
        public double Accuracy
        {
            get
            {
                return accuracy;
            }

            set
            {
                accuracy = value;
            }
        }

        //speed get/set
        public int Speed
        {
            get
            {
                return speed;
            }

            set
            {
                speed = value;
            }
        }

        //Type get
        public string Type
        {
            get
            {
                return type;
            }

        }

        public Character()
        {
        }

        //Attack the provided Character parameter
        //The damage dealt to the target is this Character's attack minus the target's defense
        //Negative damage should not be applied(counts as 0)
        //The Character should have a chance to miss. Its percent chance to successfully hit is its accuracy value
        //Output the results of combat to the console. Indicate whether the attack missed and if it didn't show how much damage was dealt by who and to who
        public void AttackTarget(Character target)
        {
            if (Accuracy > (Program.rand.NextDouble() + Program.rand.Next(0, 99)))
            {
                if (target.Health > Attack)
                {
                    target.Health -= (Attack - target.Defense);
                }
                else
                {
                    target.Health = 0;
                    
                }
                Console.WriteLine(Name + " attacked " + target.Name + " and dealt " + (Attack - target.Defense) + " damage.");


            }
            else
            {
                Console.WriteLine(Name + " tried to attack " + target.Name + " and missed.");

            }


        }

    }
}

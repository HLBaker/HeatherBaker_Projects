﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Heather Baker
/// CE08
/// Travis Setz
/// ASD 1604
/// </summary>

namespace HeatherBaker_CE08
{
    class Program
    {
        private static String[] strArray = new String[5] { "EEEEE","CCCCC","DDDDD","AAAAA","BBBBB"};
       
        static void Main(string[] args)
        {
            
            Console.WriteLine("Welcome!");
            Console.WriteLine("The current order of strings:\r\n" + strArray[0] + "," + strArray[1] + "," + strArray[2] + "," + strArray[3] + "," + strArray[4]);
 
            AscOrDsc();
            Console.WriteLine("The current order of strings:\r\n" + strArray[0] + "," + strArray[1] + "," + strArray[2] + "," + strArray[3] + "," + strArray[4]);
            Console.ReadLine();
        }


        //Ask user whether they would like to sort in ascending or decending order
        public static void AscOrDsc()
        {
            string userInput = "";
            Console.WriteLine("\r\n\r\nPlease select whether you would like to sort your information in ascending or descending order:\r\n\r\n1. Ascending\r\n2. Descending");
            userInput = Console.ReadLine().ToLower();


            while (true)
            {

                switch (userInput)
                {

                    case "1":
                    case "ascending":

                        Sort(strArray, true);
                        return;
                    case "2":
                    case "descending":

                        Sort(strArray, false);
                        return;
                    default:

                        Console.WriteLine("You have not made a valid entry, please try again.");
                        return;



                }

            }
        }

        //Sort string array ascending
        public static void Sort(String[] unsorted, bool truAscFalseDesc)
        {
            if (truAscFalseDesc)
            {
                string arrayItem;

           
                int b;

                //loops over items in arry starting at one and ending with the last entry
                for (int a = 0; a < unsorted.Count(); a++)
                {
                    b = a + 1;
                    //saves item being sorted into temporary variable
                    arrayItem = unsorted[a];
                    

                    if(b < unsorted.Count())
                    {
                        while (arrayItem.CompareTo(unsorted[b]) < 0)
                        {
                            arrayItem = unsorted[b];

                        }
                   

                            unsorted[b] = unsorted[a];
                            unsorted[a] = arrayItem;
                        }
                    }
                    
     

                }
            }
    
        }
        


}


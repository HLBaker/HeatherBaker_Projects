﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    class Chestpiece :  Armor
    {



        public override void Equip(Character C) {






        }


    }

    
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeatherBaker_CE5
{
    class Character
    {
        private string name = "Default";
        private char gender = 'F';
        private int health = 100;
        private int baseAttack = 1;
        private double Accuracy = 95.2;


        private Weapon equippedWeapon;

        public List<IEquippable> equippableList = new List<IEquippable>();
        public Dictionary<string, Armor> equippedDictionary = new Dictionary<string, Armor>();

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public char Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public int Health
        {
            get
            {
                return health;
            }

            set
            {
                health = value;
            }
        }

        public int BaseAttack
        {
            get
            {
                return baseAttack;
            }

            set
            {
                baseAttack = value;
            }
        }

        public double Accuracy
        {
            get
            {
                return Accuracy;
            }

            set
            {
                Accuracy = value;
            }
        }

        public Weapon EquippedWeapon
        {
            get
            {
                return equippedWeapon;
            }

            set
            {
                equippedWeapon = value;
            }
        }
    }
}

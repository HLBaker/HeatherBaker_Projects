﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearch
{
    interface IEquippable
    {
        void Equip(Character character);
    }
}

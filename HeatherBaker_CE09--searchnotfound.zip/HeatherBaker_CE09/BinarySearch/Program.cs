﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.IO;

namespace BinarySearch
{
    class Program
    {
        //DO NOT MODIFY MAIN()////////////////////////////////////
        //there are methods written below that you will implement to make this project function.
        static void Main(string[] args)
        {
            Character[] characters = Utility.ReadJsonData();

            while (true)
            {
                Console.WriteLine("Select what you would like to do.");
                Console.WriteLine("1. Display characters.");
                Console.WriteLine("2. Sort characters.");
                Console.WriteLine("3. Search through characters.");
                string userInput = Console.ReadLine();

                switch (userInput)
                {
                    case "1":
                        foreach(Character c in characters)
                        {
                            Console.WriteLine(c);
                        }
                        break;
                    case "2":
                        SortCharacters(characters);
                        break;
                    case "3":
                        SearchCharacters(characters);
                        break;
                    default:
                        return;
                }
            }
        }
        ////////////////////////////////////////////////////////////////

        //Write your code in this area

        //Have the user select what to sort by (Name, Weapon Name and Total Defense as options)
        static void SortCharacters(Character[] characters)
        {
            Console.WriteLine("Which field would you like to sort by? (Name, WeaponName, TotalDefense)");
            string userInput = Console.ReadLine().ToLower();
            
            while (userInput != "name" && userInput != "weaponname" && userInput != "totaldefense")
            {
                Console.WriteLine("\r\nYou have not made a valid selection.\r\n");
                Console.WriteLine("Which field would you like to sort by? (Name, WeaponName, TotalDefense)");
                userInput = Console.ReadLine().ToLower();
            }

            if(userInput == "name")
            {
                SortName(characters);
                Console.WriteLine("You have successfully sorted your characters by name.");
            }
            else if(userInput == "weaponname")
            {
                SortWeapon(characters);
                Console.WriteLine("You have successfully sorted your characters by the name of their weapon.");
            } 
            else if(userInput == "totaldefense")
            {
                SortDefense(characters);
                Console.WriteLine("You have successfully sorted your characters by the total defense of their armor.");
            }
            else
            {
                Console.WriteLine("There has been an error with your selection, please try again.");
                    
            }


        }

        //Have the user select what field to search for AND what value they want to search for in that field (Name, Weapon Name, and Total Defense as options)
        //Instead of returning the index, at the end of this method write the index to the console
        static void SearchCharacters(Character[] characters)
        {
            Console.WriteLine("Which field would you like to search? (Name, WeaponName, TotalDefense)");
            string userInput = Console.ReadLine().ToLower();

            while (userInput != "name" && userInput != "weaponname" && userInput != "totaldefense")
            {
                Console.WriteLine("\r\nYou have not made a valid selection.\r\n");
                Console.WriteLine("Which field would you like to sort by? (Name, WeaponName, TotalDefense)");
                userInput = Console.ReadLine().ToLower();
            }

            if (userInput == "name")
            {
                Console.WriteLine("What is the name that you would like to search for?");
                string searchName = Console.ReadLine().ToLower();
                SearchName(characters, searchName);
                
            }
            else if (userInput == "weaponname")
            {
                
            }
            else if (userInput == "totaldefense")
            {
                int searchInt = IntInput();
                SearchDefense(characters, searchInt);
            }
            else
            {
                Console.WriteLine("There has been an error with your selection, please try again.");

            }
        }

        //Sort by name
        static void SortName(Character[] characters)
        {
            Character tempCharacter;
            int b;

            for (int a = 0; a < characters.Count() - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (characters[b - 1].Name.CompareTo(characters[b].Name) > 0)
                    {
                        tempCharacter = characters[b - 1];
                        characters[b - 1] = characters[b];
                        characters[b] = tempCharacter;
                    }
                    b--;
                }
            }
        }

        static void SortWeapon(Character[] characters)
        {
            Character tempCharacter;
            int b;

            for (int a = 0; a < characters.Count() - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (characters[b - 1].EquippedWeapon.Name.CompareTo(characters[b].EquippedWeapon.Name) > 0)
                    {
                        tempCharacter = characters[b - 1];
                        characters[b - 1] = characters[b];
                        characters[b] = tempCharacter;
                    }
                    b--;
                }
            }
        }

        static void SortDefense(Character[] characters)
        {
            Character tempCharacter;
            int b;
 
            for (int a = 0; a < characters.Count() - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (characters[b - 1].GetTotalDefense() > characters[b].GetTotalDefense())
                    {
                        tempCharacter = characters[b - 1];
                        characters[b - 1] = characters[b];
                        characters[b] = tempCharacter;
                    }
                    b--;
                }
            }
        }

        static void SearchName(Character[] characters, string searchName)
        {
            int min = 0;
            int max = characters.Count() - 1;
            


            while (min <= max)
            {
                int mid = (min + max) / 2;
                if (searchName == characters[mid].Name.ToLower())
                {
                    Console.WriteLine("\r\nA match has been found.\r\n\r\nCharacter Match Information:\r\n");
                    characters[mid].DisplayStatus();
                    Console.WriteLine("Total Defense: " + characters[mid].GetTotalDefense());
                }
                else if (searchName.CompareTo(characters[mid].Name.ToLower()) > 0)
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }

                if (min > max)
                {
                    Console.WriteLine("No character has been found with matching paramaters, please try another search.");
                }

            }



        }

        static void SearchWeapon(Character[] characters, string searchWeapon)
        {

        }


        static void SearchDefense(Character[] characters, int searchDefense)
        {

        }

        static int IntInput()
        {
            Console.WriteLine("Please enter the total defense value you would like to search for as an integer.");
            int intInput = 0;
            string userInput = "";
            while (true)
            {
                userInput = Console.ReadLine();
                try
                {
                    intInput = Convert.ToInt32(userInput);
                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input.\r\nPlease enter the total defense value you would like to search for as an integer.");
                }
            }
            return intInput;


        }

    }
}

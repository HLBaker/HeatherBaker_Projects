﻿using System;
using System.Collections.Generic;
using System.IO;

namespace FinalPractical
{
    class CombatEnvironment
    {
        //Declare variables for streamwriter
        private static string outputFolder = @"..\..\Output";
        private static string outputFile = @"\CombatLog.txt";



        //probably need to store the combatants in this class
        List<Character> currentPlayers = new List<Character>();
        List<Character> currentMonsters = new List<Character>();

        //Get for output folder location
        public static string OutputFolder
        {
            get
            {
                return outputFolder;
            }

        }

        //Get for outputFile location
        public static string OutputFile
        {
            get
            {
                return outputFile;
            }

        }

        //Sorts parameter combatantsParam by speed
        public CombatEnvironment(List<Character> combatantsParam)
        {
            //sorting combatants by speed would be a good idea

            //Sorts combatants by speed
            int size = combatantsParam.Count / 2;
            int i;
            for (i = 0; i < size; i++)
            {
                currentPlayers.Add(combatantsParam[i]);
            }
            for (; i < combatantsParam.Count; i++)
            {
                currentMonsters.Add(combatantsParam[i]);
            }

            currentPlayers = SortLists(currentPlayers);
            currentMonsters = SortLists(currentMonsters);
        }

        public void ResolveCombat()
        {

            //Creates directory for CombatLog.txt if does not already exist
            Directory.CreateDirectory(OutputFolder);


            //to start, display information about all combatants
            //when displaying information include the type of Character(Monster or Player), health, attack, defense, and speed

            //Displays combatants before begining combat
           Log("The combatants:\r\n\r\n");
            foreach (Character c in currentPlayers)
            {
                Log("Type: " + c.TypeName);
               Log("Name: " + c.Name);
              Log("Health: " + c.Health);
              Log("Attack: " + c.Attack);
               Log("Defense: " + c.Defense);
          Log("Speed: " + c.Speed + "\r\n\r\n");
            }

            foreach (Character c in currentMonsters)
            {
        Log("Type: " + c.TypeName);
               Log("Name: " + c.Name);
        Log("Health: " + c.Health);
          Log("Attack: " + c.Attack);
           Log("Defense: " + c.Defense);
               Log("Speed: " + c.Speed + "\r\n\r\n");
            }


            int p = 0;
            int m = 0;

            while (currentMonsters.Count > 0 && currentPlayers.Count > 0)
            {

                for (; p < currentPlayers.Count; p++)
                {
                    if (currentPlayers.Count == 0 || currentMonsters.Count == 0)
                    {
                        break;
                    }
                    if (m == currentMonsters.Count)
                    {
                        currentPlayers[p].AttackTarget(currentMonsters[m - 1]);

                        if (currentMonsters[m - 1].Health <= 0)
                        {
                            currentMonsters.RemoveAt(m - 1);
                            m--;
                            if (m < 0)
                            {
                                m = 0;
                            }
                        }
                    }

                    else if (currentPlayers[p].Speed >= currentMonsters[m].Speed)
                    {
                        currentPlayers[p].AttackTarget(currentMonsters[m]);
                        if (currentMonsters[m].Health <= 0)
                        {
                            currentMonsters.RemoveAt(m);
                            m--;
                            if (m < 0)
                            {
                                m = 0;
                            }
                        }



                    }
                    else
                    {
                        p++;
                        break;
                    }


                }

                for (; m < currentMonsters.Count; m++)
                {
                    if (currentPlayers.Count == 0 || currentMonsters.Count == 0)
                    {
                        break;
                    }
                    if (p == currentPlayers.Count)
                    {
                        currentMonsters[m].AttackTarget(currentPlayers[p - 1]);

                        if (currentPlayers[p - 1].Health <= 0)
                        {
                            currentPlayers.RemoveAt(p - 1);
                            p--;
                            if (p < 0)
                            {
                                p = 0;
                            }
                        }
                    }

                    else if (currentMonsters[m].Speed >= currentPlayers[p].Speed)
                    {
                        currentMonsters[m].AttackTarget(currentPlayers[p]);
                        if (currentPlayers[p].Health <= 0)
                        {
                            currentPlayers.RemoveAt(p);
                            p--;
                            if (p < 0)
                            {
                                m = 0;
                            }
                        }



                    }
                    else
                    {
                        m++;
                        break;
                    }

                }

                if (p == currentPlayers.Count && m == currentMonsters.Count)
                {
                    p = m = 0;


                    //Displays each characters startus after each round
                    Log("\r\n\r\nYou have reached the end of the round.\r\n\r\n");
                    Log("Your combatants current status:\r\n\r\n");
                    foreach (Character c in currentPlayers)
                    {
                        Log("Type: " + c.TypeName);
                        Log("Name: " + c.Name);
                        Log("Health: " + c.Health);
                        Log("Attack: " + c.Attack);
                        Log("Defense: " + c.Defense);
                        Log("Speed: " + c.Speed + "\r\n\r\n");
                    }

                    foreach (Character c in currentMonsters)
                    {
                        Log("Type: " + c.TypeName);
                        Log("Name: " + c.Name);
                        Log("Health: " + c.Health);
                        Log("Attack: " + c.Attack);
                        Log("Defense: " + c.Defense);
                        Log("Speed: " + c.Speed + "\r\n\r\n");
                    }

                }

                //every round each Character should attack one other Character of the opposing type (Players attack Monsters, and Monsters attack Players)

                //The Characters should attack in the order of highest speed to lowest speed
                //If a Character's health falls to 0 or below 0 then it has died and should be removed from the CombatEnvironment
                //After each round of combat each Character's information should be displayed with updated health values
                //After each round of combat, check to see if all Players or all Monsters have died. If one side has no remaining objects, end the combat and display which side was victorious
            }

            //writes the victor of the battle
            if (currentMonsters.Count > 0)
            {

                Log("\r\n\r\nYour battle has ended, the Monsters have been victorious");
            }
            else
            {
                Log("\r\n\r\nYour battle has ended, the Players have been victorious");

            }
            Console.ReadLine();
        }

        //Sorts parameter list with insertion ascending, returns sorted list
        public List<Character> SortLists(List<Character> list)
        {

            Character tempCharacter;
            int b;

            for (int a = 0; a < list.Count - 1; a++)
            {
                b = a + 1;

                while (b > 0)
                {
                    if (list[b - 1].Speed > list[b].Speed)
                    {
                        tempCharacter = list[b - 1];
                        list[b - 1] = list[b];
                        list[b] = tempCharacter;
                    }
                    b--;
                }
            }

            return list;
        }

        //Writes parameter logInto to the console and CombatLog.txt file
        public static void Log(string logInfo)
        {

            try
            {

                using (StreamWriter combatLogStream = new StreamWriter(OutputFolder + OutputFile))
                {

                    combatLogStream.WriteLine(logInfo);

                }

            }
            catch (Exception)
            {
                Console.WriteLine("There has been an error writing information to your combat log, please try again.");
            }
            finally
            {
                Console.WriteLine(logInfo);
            }


        }

    }
}

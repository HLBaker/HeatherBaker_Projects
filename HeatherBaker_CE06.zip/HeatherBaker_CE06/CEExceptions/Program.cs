﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Security;

namespace CEExceptions
{
    class Program
    {
        //This program follows a set of procedural steps and has the potential to throw a lot of exceptions
        static void Main(string[] args)
        {
            //Initialize the variables that will be used in this application
            WebClient apiConnection = new WebClient();
            Person thePerson = new Person();
            String userInput = "";
            String apiEndPoint = @"https://www.govtrack.us/api/v2/person?limit=10";
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(APIdata));
            APIdata data = new APIdata();

            //Display introduction
            Console.WriteLine("The purpose of this application is to enter information about a person. Let's begin.");

            //Ask the user for their name
            Console.WriteLine("What is the person's full name? (first middle last)");
            userInput = Console.ReadLine();

            //separate the first, middle, and last names out of the user input and store them in the Person object
            try
            {
                String[] names = userInput.Split(' ');
                thePerson.FirstName = names[0];
                thePerson.MiddleName = names[1];
                thePerson.LastName = names[2];
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("This message would be thrown if the user did not put at least two spaces in their input.");
                Console.WriteLine(e.Message);
                return;
            }
            catch (ArrayTypeMismatchException e)
            {

                Console.WriteLine("This message would be thrown if the array attempting to be assigned in line 32 was not a string. This will not happen in this program because the Console.ReadLine() will always return a string. However, if it were to have an array of objects, such as an array of Weapon objects, this error would be thrown.");
                Console.WriteLine(e.Message);
                return;
            }

            

            //ask the user for their age
            Console.WriteLine("What is the person's age?");
            userInput = Console.ReadLine();

            //convert the age to an int and store it in the Person object
            try
            {
                thePerson.Age = Convert.ToInt32(userInput);
            }
            catch(FormatException e)
            {
                Console.WriteLine("This message would be thrown if the user did not input an integer. Examples: entering '3.4' or 'bob' would throw this exception.");
                Console.WriteLine(e.Message);
                return;
            }

            //Ask the user to provide some miscellaneous traits and add them to the Person object
            Console.WriteLine("Provide some traits of your choice.");
            Console.WriteLine("How many traits will you add? (Maximum of 5)");
            userInput = Console.ReadLine();
            try
            {
                int numTraits = Convert.ToInt32(userInput);
                if(numTraits > 5)
                {
                    numTraits = 5;
                }

                //ask for as many traits as the user specified and add them to the Person object
                for (int i = 0; i < numTraits; i++)
                {
                    Console.WriteLine("What is the name of this trait?");
                    string traitName = Console.ReadLine();

                    Console.WriteLine("What is the value of this trait?");
                    string traitValue = Console.ReadLine();
                    
                    thePerson.AddTrait(traitName, traitValue);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return;
            }

            //display the Person object that the user created
            try
            {
                Console.WriteLine("This is the data you have entered:");
                Console.WriteLine(thePerson);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.StackTrace);
                return;
            }

            //inform the user that we will now be downloading some additional Person objects
            Console.WriteLine("We will now download some additional people from an online API.");

            //read in some objects from an API; you may not recognize how this code works, but researching what exceptions it may throw is still the same
            try
            {
                Stream apiStream = apiConnection.OpenRead(apiEndPoint);

                data = (APIdata)ser.ReadObject(apiStream);

                apiStream.Close();
            }
            catch (DirectoryNotFoundException e)
            {
                Console.WriteLine("This exception would be thrown if the stream reader was unable to find parts of the directory https://www.govtrack.us/api/v2/person?limit=10");
                Console.WriteLine(e.Message);
                return;
            }
            catch (FileNotFoundException e) {

                Console.WriteLine("This exception would be thrown if the stream reader was attempting to access a file that did not exist.");
                Console.WriteLine(e.Message);
                return;
            }
            catch (SecurityException e) {

                Console.WriteLine("This exception would be thrown if the user did not have permission to access the information located at https://www.govtrack.us/api/v2/person?limit=10");
                Console.WriteLine(e.Message);

            }

            //let the user select which of these people that they want to see all of the information about.
            while (true)
            {
                try
                {
                    Console.WriteLine("Which of these people would you like to see full details on? (Enter e to exit)");
                    for (int i = 0; i < data.People.Count; i++)
                    {
                        Console.WriteLine(String.Format("{0}.{1} {2}\n", i, data.People[i].FirstName, data.People[i].LastName));
                    }
                    userInput = Console.ReadLine();
                    if (userInput.ToLower().Equals("e"))
                    {
                        break;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine(data.People[Convert.ToInt32(userInput)]);
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                    return;
                }
            }

            //end of program
        }
    }
}

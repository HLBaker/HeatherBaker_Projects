﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HeatherBaker_CE07
{
    class Program
    {
        static string dataFile1Location = @"..\..\DataFile1.txt";
        static string dataFile2Location = @"..\..\DataFile2.txt";
        static string dataFile3Location = @"..\..\DataFile3.txt";
        static string dataFieldsLayoutLocation = @"..\..\DataFieldsLayout.txt";
        static string outputFolder = @"..\..\Output";



        static void Main(string[] args)
        {

            //Verify/Create directory
            Directory.CreateDirectory(outputFolder);


            Console.WriteLine("Welcome!");

            while (true)
            {

                string userInput;

                Console.WriteLine("Choose whether you would like to process one of three data files into a Json object array or exit the program.\r\n\r\n1. Process File\r\n2. Exit");
                userInput = Console.ReadLine();

                switch (userInput)
                {

                    case "1":
                        ProcessFile();
                        break;
                    case "2":

                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("You have not made a valid selection.");
                        break;


                }


            }

        }


        public static void ProcessFile()
        {
            string userInput;
            string chosenFile = "";
            string formattedString = "[";

            String[] inReaderLine;
            String[] dataFieldHeaders = new String[150];





            while (chosenFile == "")
            {
                Console.WriteLine("Please select the file you would like to process into Json format.\r\n\r\n1. DataFile1\r\n2. DataFile2\r\n3. DataFile3");
                userInput = Console.ReadLine();

                switch (userInput)
                {
                    case "1":
                    case "DataFile1":

                        chosenFile = dataFile1Location;

                        break;
                    case "2":
                    case "DataFile2":

                        chosenFile = dataFile2Location;

                        break;

                    case "3":
                    case "DataFile3":

                        chosenFile = dataFile3Location;

                        break;
                    default:
                        Console.WriteLine("You have not made a valid selection.");

                        break;

                }

            }

            //create array of datafields
            int i = 0;

            try
            {
                using (StreamReader inStream = new StreamReader(dataFieldsLayoutLocation))
                {
                    while (i <= 149)
                    {
                        dataFieldHeaders[i] = inStream.ReadLine();
                        i++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("There has been an error reading your data, please try again.");
                Console.WriteLine(e.Message);
            }



            try
            {
                using (StreamReader inStream = new StreamReader(chosenFile))
                {
                    //skip first line  
                    inStream.ReadLine();

                    for (int i2 = 1; i2 <= 99; i2++)
                    {
                        inReaderLine = inStream.ReadLine().Split('|');
                        formattedString += StringJsonObject(dataFieldHeaders, inReaderLine) + ",";
                    }
                    inReaderLine = inStream.ReadLine().Split('|');
                    formattedString += StringJsonObject(dataFieldHeaders, inReaderLine) + "]";

                }
            }
            catch (Exception e)
            {
                Console.WriteLine("There has been an error converting your data, please try again.");
                Console.WriteLine(e.Message);
            }

            try
            {
                using (StreamWriter outStream = new StreamWriter(outputFolder + @"\JsonOutputOf" + chosenFile))
                {
                    outStream.WriteLine(formattedString);

                }

                Console.WriteLine("Your Json file is located in the Output folder of this program.");


            }
            catch (Exception e)
            {
                Console.WriteLine("There has been an error writing your Json array to the file, please try again.");
                Console.WriteLine(e.Message);
                
            }
        }
            

        



        public static string StringJsonObject(String[] headers, String[] data)
        {
            String[] jsonPairs = new String[150];
            string jsonObject = "{";



            try
            {


                for (int i = 0; i < 149; i++)
                {

                    jsonPairs[i] = "\"" + headers[i] + "\":\"" + data[i] + "\",";
                    i++;

                }

                jsonPairs[149] = "\"" + headers[149] + "\":\"" + data[149] + "\"}";


            }
            catch(Exception e)
            {
                Console.WriteLine("There has been an error formatting your data, please try again.");
                Console.WriteLine(e.Message);
            }


            try
            {
                for (int i1 = 0; i1 < 150; i1++)
                {

                    jsonObject += jsonPairs[i1];


                }
            }
            catch (Exception e)
            {
                Console.WriteLine("There has been an error formatting your data,");
                Console.WriteLine();
            }


            return jsonObject;
        }
    }
}

